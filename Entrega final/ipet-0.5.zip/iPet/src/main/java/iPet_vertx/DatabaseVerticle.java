package iPet_vertx;

import java.util.Date;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.json.Json;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.Router;
import io.vertx.ext.web.RoutingContext;
import io.vertx.ext.web.handler.BodyHandler;
import io.vertx.mysqlclient.MySQLClient;
import io.vertx.mysqlclient.MySQLConnectOptions;
import io.vertx.mysqlclient.MySQLPool;
import io.vertx.sqlclient.PoolOptions;
import io.vertx.sqlclient.Row;
import io.vertx.sqlclient.RowSet;
import io.vertx.sqlclient.Tuple;
import type.Collar;
import type.Humano;
import type.Perro;
import type.Sensor;
import type.SensorValue;

public class DatabaseVerticle extends AbstractVerticle {

	private MySQLPool mySQLPool;

	@Override
	public void start(Promise<Void> startPromise) {
		MySQLConnectOptions mySQLConnectOptions = new MySQLConnectOptions().setPort(3306).setHost("localhost")
				.setDatabase("ipet_db").setUser("root").setPassword("1111");
		PoolOptions poolOptions = new PoolOptions().setMaxSize(5);
		mySQLPool = MySQLPool.pool(vertx, mySQLConnectOptions, poolOptions);

		Router router = Router.router(vertx);
		vertx.createHttpServer().requestHandler(router::handle).listen(8080, result -> {
			if (result.succeeded()) {

				startPromise.complete();
			} else {
				startPromise.fail(result.cause());
			}
		});

		router.route("/ipet*").handler(BodyHandler.create()); // IMPORTANTE QUE EST� LO PRIMERO

		// ----------------------[USUARIO]----------------------
		router.put("/ipet/user/newUser").handler(this::addUser);
		router.get("/ipet/users").handler(this::getAllUsers);
		router.get("/ipet/user/:idHumano").handler(this::getUser);
		router.get("/ipet/user/dog/:idHumano").handler(this::getDogByUser);
		router.delete("/ipet/user/deleteUser/:idHumano").handler(this::deleteUser);
		router.post("/ipet/user/updatePass").handler(this::updatePass);
		router.post("/ipet/user/updateAddress").handler(this::updateAddress);
		router.post("/ipet/user/updatePhone/").handler(this::updatePhone);

		// ----------------------[PERRO]----------------------
		router.put("/ipet/dog/newdog").handler(this::addDog);
		router.get("/ipet/dogs").handler(this::getAllDogs);
		router.get("/ipet/dog/:idPerro").handler(this::getDog);
		router.delete("/ipet/dog/deleteDog/:idCollar").handler(this::deleteDog);
		router.post("/ipet/dog/updateAge").handler(this::updateAge);
		router.post("/ipet/dog/updateWeight").handler(this::updateWeight);
		router.post("/ipet/dog/updateHealth").handler(this::updateHealth);

		// ----------------------[COLLAR]----------------------
		router.put("/ipet/collar/newCollar").handler(this::addCollar);
		router.get("/ipet/collars").handler(this::getAllCollars);
		router.get("/ipet/collar/:idCollar").handler(this::getCollar);
		router.delete("/ipet/collar/deleteCollar/:idCollar").handler(this::deleteCollar);

		// ----------------------[SENSOR]----------------------
		router.put("/ipet/sensor/newSensor").handler(this::addSensor);
		router.get("/ipet/sensors/:idCollar").handler(this::getAllSensorsByCollar);
		router.delete("/ipet/sensor/deleteSensor/:idSensor").handler(this::deleteSensor);

		// ----------------------[SENSORVALUE]----------------------
		router.put("/ipet/sensorValue/newSensor").handler(this::addSensorValue);
		router.get("/ipet/sensorValue/:idSensor").handler(this::getValueBySensor);
		router.get("/ipet/sensorValue/collar/:idCollar").handler(this::getValueByCollar);
		router.delete("/ipet/sensorValue/deleteSensor/:idSensor").handler(this::deleteSensorValue);
		router.post("/ipet/sensorValue/updateValue").handler(this::updateValue);
		router.post("/ipet/sensorValue/updateAccuracy").handler(this::updateAccuracy);

	}

	private long fechaActual() {
		Date fecha = new Date();
		long ts = fecha.getTime();
		System.out.println(ts);

		return ts;
	}

	// #######################[TABLA USUARIO]#######################

	// ---------------------[M�TODO PARA A�ADIR UN USUARIO]----------------------
	private void addUser(RoutingContext routingContext) {
		Humano humano = Json.decodeValue(routingContext.getBodyAsString(), Humano.class);
		mySQLPool.preparedQuery(
				"INSERT INTO ipet_db.humano (nombre, direccion, telefono, contrase�a, idPerro) VALUES (?,?,?,?,?)",
				Tuple.of(humano.getNombre(), humano.getDireccion(), humano.getTelefono(), humano.getContrase�a(),
						humano.getIdPerro()),
				handler -> {
					if (handler.succeeded()) {
						System.out.println("El usuario se ha a�adido con �xito.");
						long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
						humano.setIdHumano((int) id);
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(humano).encodePrettily());
					} else {
						System.out.println("Error al a�adir usuario.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA OBTENER TODOS LOS USUARIOS]----------------------
	private void getAllUsers(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM ipet_db.humano", res -> {
			if (res.succeeded()) {
				RowSet<Row> resultSet = res.result();
				System.out.println("Se han obtenido un total de " + resultSet.size() + " usuarios.");
				JsonArray result = new JsonArray();
				for (Row row : resultSet) {
					result.add(JsonObject.mapFrom(new Humano(row.getInteger("idHumano"), row.getString("nombre"),
							row.getString("direccion"), row.getInteger("telefono"), row.getString("contrase�a"),
							row.getInteger("idPerro"))));
				}
				routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
						.end(result.encodePrettily());
			} else {
				routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end(JsonObject.mapFrom(res.cause()).encodePrettily());
				System.out.println("Error al obtener los usuarios.");
				System.out.println(res.cause().toString());
			}
		});
	}

	// ---------------------[M�TODO PARA OBTENER UN USUARIO]----------------------
	private void getUser(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM ipet_db.humano WHERE idHumano =" + routingContext.request().getParam("idHumano"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("Se ha obtenido el usuario asociado al id. "
								+ routingContext.request().getParam("idHumano") + ".");
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Humano(row.getInteger("idHumano"),
									row.getString("nombre"), row.getString("direccion"), row.getInteger("telefono"),
									row.getString("contrase�a"), row.getInteger("idPerro"))));
						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al obtener el usuario.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// ---------------------[M�TODO PARA OBTENER EL PERRO DE UN USUARIO]----------------------
	private void getDogByUser(RoutingContext routingContext) {

		mySQLPool.query(
				"SELECT * FROM ipet_db.perro LEFT JOIN ipet_db.humano ON perro.idCollar = humano.idPerro WHERE idHumano = "
						+ routingContext.request().getParam("idHumano"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("Se ha obtenido el perro asociado al id. del usuario "
								+ routingContext.request().getParam("idHumano") + ".");
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Perro(row.getString("nombre"), row.getInteger("edad"),
									row.getString("salud"), row.getInteger("idCollar"), row.getFloat("peso"))));
						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al obtener el perro.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// ---------------------[M�TODO PARA ELIMINAR UN USUARIO]----------------------
	private void deleteUser(RoutingContext routingContext) {
		mySQLPool.query("DELETE FROM ipet_db.humano WHERE idHumano = " + routingContext.request().getParam("idHumano"),
				res -> {
					if (res.succeeded()) {
						System.out.println("El usuario con id. " + routingContext.request().getParam("idHumano")
								+ " eliminado correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El usuario con id. " + routingContext.request().getParam("idHumano")
										+ " eliminado correctamente.");
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al eliminar el usuario.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR LA CONTRASE�A DE UN USUARIO]----------------------
	private void updatePass(RoutingContext routingContext) {
		Humano humano = Json.decodeValue(routingContext.getBodyAsString(), Humano.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.humano SET contrase�a = ? WHERE idHumano = ?",
				Tuple.of(humano.getContrase�a(), humano.getIdHumano()), res -> {
					if (res.succeeded()) {
						System.out.println("La contrase�a del id. usuario " + humano.getIdHumano()
								+ " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("La contrase�a del id. usuario " + humano.getIdHumano()
										+ " actualizada correctamente.");
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al actualizar la contrase�a.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR LA DIRECCION DE UN USUARIO]----------------------
	private void updateAddress(RoutingContext routingContext) {
		Humano humano = Json.decodeValue(routingContext.getBodyAsString(), Humano.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.humano SET direccion = ? WHERE idHumano = ?",
				Tuple.of(humano.getDireccion(), humano.getIdHumano()), res -> {
					if (res.succeeded()) {
						System.out.println(
								"La direcci�n del id. usuario " + humano.getIdHumano() + " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json").end(
								"La direcci�n del id. usuario " + humano.getIdHumano() + " actualizada correctamente.");
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al obtener la direcci�n.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR EL TELEFONO DE UN USUARIO]----------------------
	private void updatePhone(RoutingContext routingContext) {
		Humano humano = Json.decodeValue(routingContext.getBodyAsString(), Humano.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.humano SET telefono = ? WHERE idHumano = ?",
				Tuple.of(humano.getTelefono(), humano.getIdHumano()), res -> {
					if (res.succeeded()) {
						System.out.println(
								"El tel�fono del id. usuario " + humano.getIdHumano() + " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json").end(
								"El tel�fono del id. usuario " + humano.getIdHumano() + " actualizada correctamente.");
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al actualizar el tel�fono.");
						System.out.println(res.cause().toString());
					}

				});
	}

	// #######################[TABLA PERRO]#######################

	// ---------------------[M�TODO PARA A�ADIR UN PERRO]----------------------
	private void addDog(RoutingContext routingContext) {
		Perro perro = Json.decodeValue(routingContext.getBodyAsString(), Perro.class);
		mySQLPool.preparedQuery("INSERT INTO ipet_db.perro (nombre, edad, salud, idCollar, peso) VALUEs (?,?,?,?,?)",
				Tuple.of(perro.getNombre(), perro.getEdad(), perro.getSalud(), perro.getIdCollar(), perro.getPeso()),
				handler -> {
					if (handler.succeeded()) {
						System.out.println("El perro se ha a�adido con �xito.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(perro).encodePrettily());
					} else {
						System.out.println("Error al a�adir el perro.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());

					}
				});
	}

	// ---------------------[M�TODO PARA OBTENER TODOS LOS PERROS]----------------------
	private void getAllDogs(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM ipet_db.perro", res -> {
			if (res.succeeded()) {
				RowSet<Row> resultSet = res.result();
				System.out.println("Se han obtenido un total de " + resultSet.size() + " perros.");
				JsonArray result = new JsonArray();
				for (Row row : resultSet) {
					result.add(JsonObject.mapFrom(new Perro(row.getString("nombre"), row.getInteger("edad"),
							row.getString("salud"), row.getInteger("idCollar"), row.getFloat("peso"))));
				}
				routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
						.end(result.encodePrettily());
			} else {
				routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end(JsonObject.mapFrom(res.cause()).encodePrettily());
				System.out.println("Error al obtener los perros.");
				System.out.println(res.cause().toString());
			}
		});
	}

	// ---------------------[M�TODO PARA OBTENER UN PERRO]----------------------
	private void getDog(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM ipet_db.perro WHERE idCollar = " + routingContext.request().getParam("idPerro"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("Se ha obtenido el perro asociado al id. "
								+ routingContext.request().getParam("idPerro") + ".");
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Perro(row.getString("nombre"), row.getInteger("edad"),
									row.getString("salud"), row.getInteger("idCollar"), row.getFloat("peso"))));
						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al obtener el perro.");
						System.out.println(res.cause().toString());

					}
				});
	}

	// ---------------------[M�TODO PARA ELIMINAR UN PERRO]----------------------
	private void deleteDog(RoutingContext routingContext) {
		mySQLPool.query("DELETE FROM ipet_db.perro WHERE idCollar = " + routingContext.request().getParam("idCollar"),
				handler -> {
					if (handler.succeeded()) {
						System.out.println("El perro con id. " + routingContext.request().getParam("idCollar")
								+ " eliminado correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El perro con id. " + routingContext.request().getParam("idCollar")
										+ " eliminado correctamente.");
					} else {
						System.out.println("Error al eliminar el perro.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ACTUALIDAR LA EDAD DE UN PERRO]----------------------
	private void updateAge(RoutingContext routingContext) {
		Perro perro = Json.decodeValue(routingContext.getBodyAsString(), Perro.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.perro SET edad = ? WHERE idCollar = ?",
				Tuple.of(perro.getEdad(), perro.getIdCollar()), handler -> {
					if (handler.succeeded()) {
						System.out.println(
								"La edad del id. perro " + perro.getIdCollar() + " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("La edad del id. perro " + perro.getIdCollar() + " actualizada correctamente.");
					} else {
						System.out.println("Error al actualizar la edad.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR EL PESO UN PERRO]----------------------
	private void updateWeight(RoutingContext routingContext) {
		Perro perro = Json.decodeValue(routingContext.getBodyAsString(), Perro.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.perro SET peso = ? WHERE idCollar = ?",
				Tuple.of(perro.getPeso(), perro.getIdCollar()), handler -> {
					if (handler.succeeded()) {
						System.out
								.println("El peso del id. perro" + perro.getIdCollar() + " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El peso del id. perro " + perro.getIdCollar() + " actualizada correctamente.");
					} else {
						System.out.println("Error al actualizar el peso.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR LA SALUD UN PERRO]----------------------
	private void updateHealth(RoutingContext routingContext) {
		Perro perro = Json.decodeValue(routingContext.getBodyAsString(), Perro.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.perro SET salud = ? WHERE idCollar = ?",
				Tuple.of(perro.getSalud(), perro.getIdCollar()), handler -> {
					if (handler.succeeded()) {
						System.out.println(
								"La salud del id. perro" + perro.getIdCollar() + " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("La salud del id. perro" + perro.getIdCollar() + " actualizada correctamente.");
					} else {
						System.out.println("Error al actualizar la salud.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// #######################[TABLA COLLAR]#######################

	// ---------------------[M�TODO PARA A�ADIR UN COLLAR]----------------------
	private void addCollar(RoutingContext routingContext) {
		Collar collar = Json.decodeValue(routingContext.getBodyAsString(), Collar.class);
		mySQLPool.query("INSERT INTO ipet_db.collar (timestamp) VALUEs (" + fechaActual() + ")", handler -> {
			if (handler.succeeded()) {
				System.out.println("El collar se ha a�adido con �xito.");
				long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
				collar.setIdCollar((int) id);

				routingContext.response().setStatusCode(200).putHeader("content-type", "application/json").end();
			} else {
				System.out.println("Error al a�adir el collar.");
				System.out.println(handler.cause().toString());
				routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
			}
		});
	}

	// ---------------------[M�TODO PARA OBTENER TODOS LOS COLLARES]----------------------
	private void getAllCollars(RoutingContext routingContext) {
		mySQLPool.query("SELECT * FROM ipet_db.collar", res -> {
			if (res.succeeded()) {
				RowSet<Row> resultSet = res.result();
				System.out.println("Se han obtenido un total de " + resultSet.size() + " collares.");
				JsonArray result = new JsonArray();
				for (Row row : resultSet) {
					result.add(JsonObject.mapFrom(new Collar(row.getInteger("idCollar"), row.getLong("timestamp"))));
				}
				routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
						.end(result.encodePrettily());
			} else {
				System.out.println("Error al obtener los collares.");
				System.out.println(res.cause().toString());
				routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
						.end(JsonObject.mapFrom(res.cause()).encodePrettily());
			}
		});
	}

	// ---------------------[M�TODO PARA OBTENER UN COLLAR]----------------------
	private void getCollar(RoutingContext routingContext) {
		mySQLPool.query(
				"SELECT * FROM ipet_db.collar WHERE idCollar = " + routingContext.request().getParam("idCollar"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("Se ha obtenido el collar asociado al id. "
								+ routingContext.request().getParam("idCollar") + ".");
						JsonArray result = new JsonArray();

						for (Row row : resultSet) {
							result.add(JsonObject
									.mapFrom(new Collar(row.getInteger("idCollar"), row.getLong("timestamp"))));

						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						System.out.println("Error al obtener el collar.");
						System.out.println(res.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());

					}

				});
	}

	// ---------------------[M�TODO PARA ELIMINAR UN COLLAR]----------------------
	private void deleteCollar(RoutingContext routingContext) {
		mySQLPool.query("DELETE FROM ipet_db.collar WHERE idCollar = " + routingContext.request().getParam("idCollar"),
				res -> {
					if (res.succeeded()) {
						System.out.println("El collar con id. " + routingContext.request().getParam("idCollar")
								+ " eliminado correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El collar con id. " + routingContext.request().getParam("idCollar")
										+ " eliminado correctamente.");
					} else {
						System.out.println("Error al eliminar el collar.");
						System.out.println(res.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
					}
				});
	}

	// #######################[TABLA SENSOR]#######################

	// ---------------------[M�TODO PARA A�ADIR UN SENSOR]----------------------
	private void addSensor(RoutingContext routingContext) {
		Sensor sensor = Json.decodeValue(routingContext.getBodyAsString(), Sensor.class);
		mySQLPool.preparedQuery("INSERT INTO ipet_db.Sensores (idCollar, type) VALUES (?,?)",
				Tuple.of(sensor.getIdCollar(), sensor.getTipo()), handler -> {
					if (handler.succeeded()) {
						System.out.println("El sensor se ha a�adido con �xito.");
						long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
						sensor.setIdSensor((int) id);
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(sensor).encodePrettily());
					} else {
						System.out.println("Error al a�adir el sensor.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});

	}

	// ---------------------[M�TODO PARA OBTENER TODOS LOS SENSORES DE UN COLLAR]----------------------
	private void getAllSensorsByCollar(RoutingContext routingContext) {
		mySQLPool.query(
				"SELECT * FROM ipet_db.sensores WHERE idCollar = " + routingContext.request().getParam("idCollar"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println(
								"Se han obtenido un total de " + resultSet.size() + " sensores del collar con id. "
										+ routingContext.request().getParam("idCollar") + ".");
						JsonArray result = new JsonArray();

						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new Sensor(row.getInteger("idSensor"),
									row.getInteger("idCollar"), row.getString("type"))));

						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						System.out.println("Error al obtener los sensores del collar.");
						System.out.println(res.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
					}

				});
	}

	// ---------------------[M�TODO PARA ELIMINAR UN SENSOR]----------------------
	private void deleteSensor(RoutingContext routingContext) {
		mySQLPool.query(
				"DELETE FROM ipet_db.sensores WHERE idSensor = " + routingContext.request().getParam("idSensor"),
				res -> {
					if (res.succeeded()) {
						System.out.println("El sensor con id. " + routingContext.request().getParam("idSensor")
								+ " ha sido eliminado con �xito.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El sensor con id. " + routingContext.request().getParam("idSensor")
										+ " ha sido eliminado con �xito.");
					} else {
						System.out.println("Error al eliminar el sensor.");
						System.out.println(res.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
					}
				});
	}

	// #######################[TABLA SENSORVALUE]#######################

	// ---------------------[M�TODO PARA A�ADIR UN VALOR AL SENSOR]----------------------
	private void addSensorValue(RoutingContext routingContext) {
		SensorValue sensorvalue = Json.decodeValue(routingContext.getBodyAsString(), SensorValue.class);
		long ts = fechaActual();
		mySQLPool.preparedQuery(
				"INSERT INTO ipet_db.sensorvalue (valor, timestamp, accuracy, idSensor) VALUES (?," + ts + ",?,?)",
				Tuple.of(sensorvalue.getValor(), sensorvalue.getAccuracy(), sensorvalue.getIdSensor()), handler -> {
					if (handler.succeeded()) {
						System.out.println("El valor del sensor se ha a�adido con �xito.");
						long id = handler.result().property(MySQLClient.LAST_INSERTED_ID);
						sensorvalue.setIdValue((int) id);
						sensorvalue.setTimestamp(ts);
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(sensorvalue).encodePrettily());
					} else {
						System.out.println("Error al a�adir un sensor.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA OBTENER LOS VALORES DE UN SENSOR]----------------------
	private void getValueBySensor(RoutingContext routingContext) {
		mySQLPool.query(
				"SELECT * FROM ipet_db.sensorvalue WHERE idSensor = " + routingContext.request().getParam("idSensor"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();
						System.out.println("Se ha obtenido correctamente el valor del sensor.");
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new SensorValue(row.getInteger("idValue"),
									row.getFloat("valor"), row.getLong("timestamp"), row.getFloat("accuracy"),
									row.getInteger("idSensor"))));
						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
						System.out.println("Error al obtener los valores del sensor.");
						System.out.println(res.cause().toString());
					}
				});
	}

	// ---------------------[M�TODO PARA OBTENER TODOS LOS VALORES DE LOS SENSORES DE UN COLLAR]----------------------
	private void getValueByCollar(RoutingContext routingContext) {
		mySQLPool.query(
				"SELECT sensorvalue.idValue, sensorValue.valor, sensorvalue.timestamp, sensorvalue.accuracy, sensorvalue.idSensor FROM ipet_db.sensorvalue LEFT JOIN ipet_db.sensores ON sensores.idSensor = sensorvalue.idSensor WHERE sensores.idCollar = "
						+ routingContext.request().getParam("idCollar"),
				res -> {
					if (res.succeeded()) {
						RowSet<Row> resultSet = res.result();

						System.out.println("Se han obtenido los valores de los sensores del collar con id. "
								+ routingContext.request().getParam("idCollar") + ".");
						JsonArray result = new JsonArray();
						for (Row row : resultSet) {
							result.add(JsonObject.mapFrom(new SensorValue(row.getInteger("idValue"),
									row.getFloat("valor"), row.getLong("timestamp"), row.getFloat("accuracy"),
									row.getInteger("idSensor"))));

						}
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end(result.encodePrettily());
					} else {
						System.out.println("Error al obtener valores del collar.");
						System.out.println(res.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(res.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ELIMINAR LOS VALORES DE UN SENSOR]----------------------
	private void deleteSensorValue(RoutingContext routingContext) {
		mySQLPool.query(
				"DELETE FROM ipet_db.sensorvalue WHERE idValue = " + routingContext.request().getParam("idValue"),
				handler -> {
					if (handler.succeeded()) {
						System.out.println("El valor del sensor con id. " + routingContext.request().getParam("idValue")
								+ " eliminado correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El valor del sensor con id. " + routingContext.request().getParam("idValue")
										+ " eliminado correctamente.");
					} else {
						System.out.println("Error al eliminar el valor del sensor.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR EL VALOR DE UN SENSOR]----------------------
	private void updateValue(RoutingContext routingContext) {
		SensorValue sensorValue = Json.decodeValue(routingContext.getBodyAsString(), SensorValue.class);
		mySQLPool.preparedQuery(
				"UPDATE ipet_db.sensorvalue SET valor = ?, timestamp = " + fechaActual() + " WHERE idValue = ?",
				Tuple.of(sensorValue.getValor(), sensorValue.getIdValue()), handler -> {
					if (handler.succeeded()) {
						System.out.println("El valor del sensor con id." + sensorValue.getIdValue()
								+ " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("El valor del sensor con id." + sensorValue.getIdValue()
										+ " actualizada correctamente.");
					} else {
						System.out.println("Error al actualizar el valor del sensor.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}

	// ---------------------[M�TODO PARA ACTUALIZAR EL ACCURACY DE UN SENSOR]----------------------
	private void updateAccuracy(RoutingContext routingContext) {
		SensorValue sensorValue = Json.decodeValue(routingContext.getBodyAsString(), SensorValue.class);
		mySQLPool.preparedQuery("UPDATE ipet_db.sensorvalue SET accuracy = ? WHERE idValue = ?",
				Tuple.of(sensorValue.getAccuracy(), sensorValue.getIdValue()), handler -> {
					if (handler.succeeded()) {
						System.out.println("La presici�n del sensor con id." + sensorValue.getIdValue()
								+ " actualizada correctamente.");
						routingContext.response().setStatusCode(200).putHeader("content-type", "application/json")
								.end("La presici�n del sensor con id." + sensorValue.getIdValue()
										+ " actualizada correctamente.");
					} else {
						System.out.println("Error al actualizar la presici�n del sensor.");
						System.out.println(handler.cause().toString());
						routingContext.response().setStatusCode(401).putHeader("content-type", "application/json")
								.end(JsonObject.mapFrom(handler.cause()).encodePrettily());
					}
				});
	}
}
