package iPet_vertx;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Future;

public class Verticle extends AbstractVerticle{
	
	@Override
	public void start (Future<Void> startFuture) {
		vertx.deployVerticle(DatabaseVerticle.class.getName());
		vertx.deployVerticle(TelegramVerticle.class.getName());
		//vertx.deployVerticle(MqttServerVerticle.class.getName());
	}
}
