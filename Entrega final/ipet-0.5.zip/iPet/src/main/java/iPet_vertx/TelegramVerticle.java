package iPet_vertx;

import org.schors.vertx.telegram.bot.LongPollingReceiver;
import org.schors.vertx.telegram.bot.TelegramBot;
import org.schors.vertx.telegram.bot.TelegramOptions;
import org.schors.vertx.telegram.bot.api.methods.SendMessage;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;
import io.vertx.core.buffer.Buffer;
import io.vertx.core.json.JsonArray;
import io.vertx.core.json.JsonObject;
import io.vertx.ext.web.client.HttpResponse;
import io.vertx.ext.web.client.WebClient;

public class TelegramVerticle extends AbstractVerticle {

	private TelegramBot bot;

	@Override
	public void start(Promise<Void> future) {
		TelegramOptions telegramOptions = new TelegramOptions().setBotName("yoperrobot")
				.setBotToken("1239019385:AAGp7OvJnCQVSbK_HS-k-8ea-bAMBu4-Reo");

		bot = TelegramBot.create(vertx, telegramOptions).receiver(new LongPollingReceiver().onUpdate(handler -> {
			if (handler.getMessage().getText().toLowerCase().contains("hola")) {
				bot.sendMessage(new SendMessage()
						.setText("Hola " + handler.getMessage().getFrom().getFirstName()
								+ ", pulsa /comandos para ver los comandos disponibles.")
						.setChatId(handler.getMessage().getChatId()));
			} else if (handler.getMessage().getText().toLowerCase().contains("/comandos")) {

				bot.sendMessage(new SendMessage().setText("COMANDOS: ").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/hola").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/humano ").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/perro ").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/sensores").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/temperatura").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/humedad").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/luminosidad").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/microfono").setChatId(handler.getMessage().getChatId()));
				bot.sendMessage(new SendMessage().setText("/pulsometro").setChatId(handler.getMessage().getChatId()));

			} else if (handler.getMessage().getText().toLowerCase().contains("/perro"))

			{
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/dog/1").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();

						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						String nombre = perroInfo.getString("nombre");
						String salud = perroInfo.getString("salud");
						Integer edad = perroInfo.getInteger("edad");

						bot.sendMessage(new SendMessage().setText("DATOS DEL PERRO: ")
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(new SendMessage().setText("Nombre: " + nombre)
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(new SendMessage().setText("Salud: " + salud)
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(
								new SendMessage().setText("Edad: " + edad).setChatId(handler.getMessage().getChatId()));
					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/temperatura")) {
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensorValue/16").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						System.out.println(object);
						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						Float temperatura = perroInfo.getFloat("valor");

						bot.sendMessage(new SendMessage().setText("TEMPERATURA: " + temperatura + " �C")
								.setChatId(handler.getMessage().getChatId()));

					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/humedad")) {
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensorValue/17").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						System.out.println(object);
						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						Float humedad = perroInfo.getFloat("valor");

						bot.sendMessage(new SendMessage().setText("HUMEDAD: " + humedad + "%")
								.setChatId(handler.getMessage().getChatId()));

					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/luminosidad")) {
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensorValue/18").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						System.out.println(object);
						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						Float luminosidad = perroInfo.getFloat("valor");

						bot.sendMessage(new SendMessage().setText("LUMINOSIDAD: " + luminosidad + " l�menes.")
								.setChatId(handler.getMessage().getChatId()));

					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/microfono")) {
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensorValue/19").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						System.out.println(object);
						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						Integer microfono = perroInfo.getInteger("valor");
						if (microfono == 1) {
							bot.sendMessage(new SendMessage().setText("Sonido detectado, el perro est� ladrando.")
									.setChatId(handler.getMessage().getChatId()));

						} else {
							bot.sendMessage(new SendMessage().setText("Todo en silencio.")
									.setChatId(handler.getMessage().getChatId()));
						}

					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/pulsometro")) {
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensorValue/20").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						System.out.println(object);
						JsonObject perroInfo = object.getJsonObject(object.size() - 1);
						Integer pulsometro = perroInfo.getInteger("valor");

						bot.sendMessage(new SendMessage().setText("Pulsometro: " + pulsometro + " BPM.")
								.setChatId(handler.getMessage().getChatId()));

					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/humano"))

			{
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/user/4").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();

						JsonObject perroInfo = object.getJsonObject(object.size()-1);
						String nombre = perroInfo.getString("nombre");
						String direccion = perroInfo.getString("direccion");
						Integer telefono = perroInfo.getInteger("telefono");

						bot.sendMessage(new SendMessage().setText("DATOS DEL HUMANO: ")
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(new SendMessage().setText("Nombre: " + nombre)
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(new SendMessage().setText("Direccion: " + direccion)
								.setChatId(handler.getMessage().getChatId()));
						bot.sendMessage(new SendMessage().setText("Tel�fono: " + telefono)
								.setChatId(handler.getMessage().getChatId()));
					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			} else if (handler.getMessage().getText().toLowerCase().contains("/sensores"))

			{
				WebClient client = WebClient.create(vertx);
				client.get(8080, "localhost", "/ipet/sensors/1").send(ar -> {
					if (ar.succeeded()) {

						HttpResponse<Buffer> response = ar.result();
						JsonArray object = response.bodyAsJsonArray();
						bot.sendMessage(new SendMessage().setText("LISTA DE SENSORES: ")
								.setChatId(handler.getMessage().getChatId()));
						for (int i = 0; i < object.size(); i++) {
							JsonObject perroInfo = object.getJsonObject(i);

							Integer id = perroInfo.getInteger("idSensor");
							String type = perroInfo.getString("tipo");

							bot.sendMessage(
									new SendMessage().setText("Id: " + id).setChatId(handler.getMessage().getChatId()));
							bot.sendMessage(new SendMessage().setText("Tipo: " + type)
									.setChatId(handler.getMessage().getChatId()));

						}
					} else {
						bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal")
								.setChatId(handler.getMessage().getChatId()));
					}
				});
			}

		}));

		bot.start();
	}

}
