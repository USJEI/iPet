package type;

public class Perro {

	private String nombre;
	private int edad;
	private String salud;
	private int idCollar;
	private float peso;

	public Perro(String nombre, int edad, String salud, int idCollar, float peso) {
		super();
		this.nombre = nombre;
		this.edad = edad;
		this.salud = salud;
		this.idCollar = idCollar;
		this.peso = peso;
	}

	public Perro() {
		super();
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public String getSalud() {
		return salud;
	}

	public void setSalud(String salud) {
		this.salud = salud;
	}

	public int getIdCollar() {
		return idCollar;
	}

	public void setIdCollar(int idCollar) {
		this.idCollar = idCollar;
	}

	public float getPeso() {
		return peso;
	}

	public void setPeso(float peso) {
		this.peso = peso;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + edad;
		result = prime * result + idCollar;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + Float.floatToIntBits(peso);
		result = prime * result + ((salud == null) ? 0 : salud.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Perro other = (Perro) obj;
		if (edad != other.edad)
			return false;
		if (idCollar != other.idCollar)
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (Float.floatToIntBits(peso) != Float.floatToIntBits(other.peso))
			return false;
		if (salud == null) {
			if (other.salud != null)
				return false;
		} else if (!salud.equals(other.salud))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Perro [nombre=" + nombre + ", edad=" + edad + ", salud=" + salud + ", idCollar=" + idCollar + ", peso="
				+ peso + "]";
	}

}
