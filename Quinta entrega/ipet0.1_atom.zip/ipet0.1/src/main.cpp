#include <Arduino.h>
#include "ArduinoJson.h"
#include <ESP8266WiFi.h>
#include <ESP8266HTTPClient.h>
#include <SoftwareSerial.h>

char responseBuffer[300];
WiFiClient client;

String SSID = "vodafoneBA2425";
String PASS = "JFE3C6ELJ7GX7YDS";
//String SERVER_IP = "www.mocky.io";
String SERVER_IP = "192.168.0.10";
int SERVER_PORT = 8080;

void sendGetRequest();
void sendPostRequest();

void setup() {
  Serial.begin(9600);
//  Serial.setTimeout(500);
  WiFi.begin(SSID, PASS);

  Serial.print("Conectando...");
  while(WiFi.status() != WL_CONNECTED){
    delay(500);
    Serial.print(".");
  }
  Serial.print("Conectado, IP address: ");
  Serial.print(WiFi.localIP());


}

void loop() {
//  sendGetRequest();
//  delay(3000);
  sendPostRequest();
  delay(3000);
}

void sendGetRequest(){
  if(WiFi.status()== WL_CONNECTED){
    HTTPClient http;
    http.begin(client, SERVER_IP, SERVER_PORT, "/ipet/collar/1", true);
    int httpCode = http.GET();
    Serial.println("Response code: " + httpCode);
    String payload = http.getString();

    const size_t capacity = JSON_OBJECT_SIZE(5) + JSON_ARRAY_SIZE(5) + 60;
    DynamicJsonDocument doc(capacity);

    DeserializationError error = deserializeJson(doc, payload);
    if(error){
      Serial.print("deserializeJson() failed: ");
      Serial.println(error.c_str());
      return;
    }

    Serial.println(F("Reponse:"));
    // Serial.println(doc["sensor"].as<char*>());
    // Serial.println(doc["time"].as<long>());
    // Serial.println(doc["data"].as<float>(), 0);
    int idCollar = doc["idCollar"].as<int>();
    long timestamp = doc["timestamp"].as<long>();
    Serial.println("idCollar: " + String(idCollar));
    Serial.println("timestamp: " + String(timestamp));

    // Serial.println(doc["idHumano"].as<int>());
    // Serial.println(doc["nombre"].as<char*>());
    // Serial.println(doc["direccion"].as<char*>());
    // Serial.println(doc["telefono"].as<int>());
    // Serial.println(doc["contraseña"].as<char*>());
    // Serial.println(doc["idPerro"].as<int>());
  }
}

void sendPostRequest(){
  if (WiFi.status() == WL_CONNECTED){
    HTTPClient http;
    http.begin(client, SERVER_IP, SERVER_PORT, "/ipet/sensorValue/updateValue", true);
    http.addHeader("Content-Type", "application/json");

    const size_t capacity = JSON_OBJECT_SIZE(2) + JSON_ARRAY_SIZE(1) + 60;
    DynamicJsonDocument doc(capacity);

    doc["idValue"] = 28;
    doc["valor"] = 22;



    String output;
    serializeJson(doc, output);

    int httpCode = http.PUT(output);

    Serial.println("Response code: " + httpCode);

    String payload = http.getString();

    Serial.println("Resultado: " + payload);
  }
}
