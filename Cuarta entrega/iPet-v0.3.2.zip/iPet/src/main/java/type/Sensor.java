package type;

public class Sensor {

	private int idSensor;
	private int idCollar;
	private String tipo;

	public Sensor(int idSensor, int idCollar, String tipo) {
		super();
		this.idSensor = idSensor;
		this.idCollar = idCollar;
		this.tipo = tipo;
	}

	public Sensor() {
		super();
	}

	public int getIdSensor() {
		return idSensor;
	}

	public void setIdSensor(int idSensor) {
		this.idSensor = idSensor;
	}

	public int getIdCollar() {
		return idCollar;
	}

	public void setIdCollar(int idCollar) {
		this.idCollar = idCollar;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idCollar;
		result = prime * result + idSensor;
		result = prime * result + ((tipo == null) ? 0 : tipo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Sensor other = (Sensor) obj;
		if (idCollar != other.idCollar)
			return false;
		if (idSensor != other.idSensor)
			return false;
		if (tipo != other.tipo)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Sensor [idSensor=" + idSensor + ", idCollar=" + idCollar + ", tipo=" + tipo + "]";
	}

}
