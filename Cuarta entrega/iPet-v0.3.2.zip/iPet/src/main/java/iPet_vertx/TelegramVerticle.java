package iPet_vertx;

import org.schors.vertx.telegram.bot.LongPollingReceiver;
import org.schors.vertx.telegram.bot.TelegramBot;
import org.schors.vertx.telegram.bot.TelegramOptions;
import org.schors.vertx.telegram.bot.api.methods.SendMessage;

import io.vertx.core.AbstractVerticle;
import io.vertx.core.Promise;

public class TelegramVerticle extends AbstractVerticle {
	
	private TelegramBot bot;
	
	@Override
	public void start(Promise<Void> future) {
		TelegramOptions telegramOptions  = new TelegramOptions ().setBotName("yoperrobot").setBotToken("1239019385:AAGp7OvJnCQVSbK_HS-k-8ea-bAMBu4-Reo");
		
		bot = TelegramBot.create(vertx, telegramOptions).receiver(new LongPollingReceiver().onUpdate(handler -> {
			if (handler.getMessage().getText().toLowerCase().contains("hola")) {
				bot.sendMessage(new SendMessage().setText("Hola " + handler.getMessage().getFrom().getFirstName() + " �en qu� puedo ayudarte?").setChatId(handler.getMessage().getChatId()));
			} else {
				bot.sendMessage(new SendMessage().setText("Vaya, algo ha salido mal").setChatId(handler.getMessage().getChatId()));
			}
		}));
		
		bot.start();
	}
	
}
