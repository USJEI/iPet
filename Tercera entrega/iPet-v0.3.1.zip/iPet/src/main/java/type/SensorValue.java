package type;

public class SensorValue {
	
	private int idValue;
	private float valor;
	private long timestamp;
	private float accuracy;
	private int idSensor;
	
	public SensorValue(int idValue, float valor, long timestamp, float accuracy, int idSensor) {
		super();
		this.idValue = idValue;
		this.valor = valor;
		this.timestamp = timestamp;
		this.accuracy = accuracy;
		this.idSensor = idSensor;
	}

	public SensorValue() {
		super();
	}

	public int getIdValue() {
		return idValue;
	}

	public void setIdValue(int idValue) {
		this.idValue = idValue;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	public float getAccuracy() {
		return accuracy;
	}

	public void setAccuracy(float accuracy) {
		this.accuracy = accuracy;
	}

	public int getIdSensor() {
		return idSensor;
	}

	
	//�habr�a que quitar este setter al ser un heredado?
	public void setIdSensor(int idSensor) {
		this.idSensor = idSensor;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(accuracy);
		result = prime * result + idSensor;
		result = prime * result + idValue;
		result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
		result = prime * result + Float.floatToIntBits(valor);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SensorValue other = (SensorValue) obj;
		if (Float.floatToIntBits(accuracy) != Float.floatToIntBits(other.accuracy))
			return false;
		if (idSensor != other.idSensor)
			return false;
		if (idValue != other.idValue)
			return false;
		if (timestamp != other.timestamp)
			return false;
		if (Float.floatToIntBits(valor) != Float.floatToIntBits(other.valor))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "SensorValue [idValue=" + idValue + ", valor=" + valor + ", timestamp=" + timestamp + ", accuracy="
				+ accuracy + ", idSensor=" + idSensor + "]";
	}
}
