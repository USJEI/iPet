package type;

public class Humano {

	private int idHumano;
	private String nombre;
	private String direccion;
	private int telefono;
	private String contrase�a;
	private int idPerro;

	public Humano(int idHumano, String nombre, String direccion, int telefono, String contrase�a, int idPerro) {
		super();
		this.idHumano = idHumano;
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.contrase�a = contrase�a;
		this.idPerro = idPerro;
	}

	public Humano() {
		super();
	}

	public int getIdHumano() {
		return idHumano;
	}

	public void setIdHumano(int idHumano) {
		this.idHumano = idHumano;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public int getTelefono() {
		return telefono;
	}

	public void setTelefono(int telefono) {
		this.telefono = telefono;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	public int getIdPerro() {
		return idPerro;
	}

	public void setIdPerro(int idPerro) {
		this.idPerro = idPerro;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contrase�a == null) ? 0 : contrase�a.hashCode());
		result = prime * result + ((direccion == null) ? 0 : direccion.hashCode());
		result = prime * result + idHumano;
		result = prime * result + idPerro;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		result = prime * result + telefono;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Humano other = (Humano) obj;
		if (contrase�a == null) {
			if (other.contrase�a != null)
				return false;
		} else if (!contrase�a.equals(other.contrase�a))
			return false;
		if (direccion == null) {
			if (other.direccion != null)
				return false;
		} else if (!direccion.equals(other.direccion))
			return false;
		if (idHumano != other.idHumano)
			return false;
		if (idPerro != other.idPerro)
			return false;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		if (telefono != other.telefono)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Humano [idHumano=" + idHumano + ", nombre=" + nombre + ", direccion=" + direccion + ", telefono="
				+ telefono + ", contrase�a=" + contrase�a + ", idPerro=" + idPerro + "]";
	}

}
