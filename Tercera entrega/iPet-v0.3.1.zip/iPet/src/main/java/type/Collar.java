package type;

public class Collar {

	private int idCollar;
	private Long timestamp;

	public Collar(int idCollar, Long timestamp) {
		super();
		this.idCollar = idCollar;
		this.timestamp = timestamp;
	}

	public Collar() {
		super();
	}

	public int getIdCollar() {
		return idCollar;
	}

	public void setIdCollar(int idCollar) {
		this.idCollar = idCollar;
	}

	public long getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(long timestamp) {
		this.timestamp = timestamp;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + idCollar;
		result = prime * result + (int) (timestamp ^ (timestamp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Collar other = (Collar) obj;
		if (idCollar != other.idCollar)
			return false;
		if (timestamp != other.timestamp)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Collar [idCollar=" + idCollar + ", timestamp=" + timestamp + "]";
	}
}
